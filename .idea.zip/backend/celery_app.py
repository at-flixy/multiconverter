import os
import pathlib
from celery import Celery
from flask import Flask

from config import Config
from database import db

def create_flask_for_celery():
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(Config)

    os.makedirs(app.instance_path, exist_ok=True)
    db_file = pathlib.Path(app.instance_path) / "app.db"
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + db_file.as_posix()

    app.config.setdefault("SQLALCHEMY_ENGINE_OPTIONS", {})
    ce = app.config["SQLALCHEMY_ENGINE_OPTIONS"].get("connect_args", {})
    ce.update({"check_same_thread": False})
    app.config["SQLALCHEMY_ENGINE_OPTIONS"]["connect_args"] = ce

    db.init_app(app)
    return app

flask_app = create_flask_for_celery()

celery = Celery(
    flask_app.import_name,
    broker=flask_app.config.get("CELERY_BROKER_URL", "redis://redis:6379/0"),
    backend=flask_app.config.get("CELERY_RESULT_BACKEND", "redis://redis:6379/0"),
    include=["tasks"]
)
celery.conf.update(flask_app.config)

class AppContextTask(celery.Task):
    abstract = True
    def __call__(self, *args, **kwargs):
        with flask_app.app_context():
            return super().__call__(*args, **kwargs)

celery.Task = AppContextTask
