# backend/fix_paths.py
import os, pathlib
from app import app, db, File  # модели уже импортируются в app.py

CANDIDATE_BASES = [
    pathlib.Path(app.instance_path),                                # текущий instance
    pathlib.Path(r"C:\multiconverter_project_full\backend\instance") # явный путь
]

SUBS = ["uploads", "results", ""]  # где ищем

def try_relink(f):
    """Пытаемся найти файл по имени в известных папках и починить File.path"""
    name = pathlib.Path(f.path).name
    for base in CANDIDATE_BASES:
        for sub in SUBS:
            candidate = base / sub / name
            if candidate.exists():
                f.path = str(candidate)
                return True
    return False

with app.app_context():
    fixed = 0
    missing = 0
    all_files = File.query.all()
    for f in all_files:
        if os.path.exists(f.path):
            continue
        if try_relink(f):
            fixed += 1
        else:
            missing += 1
    db.session.commit()
    print(f"Relinked: {fixed}, still missing: {missing}, total: {len(all_files)}")
