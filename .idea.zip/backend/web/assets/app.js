;(() => {
	const API =
		window.location.origin.includes('127.0.0.1') ||
		window.location.origin.includes('localhost')
			? 'http://127.0.0.1:5000'
			: window.location.origin
	const $ = (s, el = document) => el.querySelector(s)
	const $$ = (s, el = document) => Array.from(el.querySelectorAll(s))
	const toast = m => {
		const t = $('#toast')
		t.textContent = m
		t.style.display = 'block'
		setTimeout(() => (t.style.display = 'none'), 2500)
	}
	const tokenKey = 'mc_token'
	const setToken = t => localStorage.setItem(tokenKey, t)
	const getToken = () => localStorage.getItem(tokenKey)
	const authHeader = () =>
		getToken() ? { Authorization: 'Bearer ' + getToken() } : {}
	const api = async (path, opts = {}) => {
		const res = await fetch(API + path, {
			...opts,
			headers: {
				'Content-Type': 'application/json',
				...authHeader(),
				...(opts.headers || {}),
			},
		})
		if (!res.ok) {
			throw new Error('HTTP ' + res.status)
		}
		const ct = res.headers.get('content-type') || ''
		return ct.includes('application/json') ? res.json() : res
	}
	const updateUserLabel = async () => {
		const label = $('#user-label')
		const btn = $('#btn-auth')
		if (!getToken()) {
			label.textContent = 'Гость'
			btn && (btn.onclick = () => $('#auth-modal').classList.add('show'))
			return
		}
		try {
			const me = await api('/api/me')
			label.textContent = me.email
			btn && (btn.onclick = () => toast('Вы уже авторизованы'))
		} catch {
			label.textContent = 'Гость'
			localStorage.removeItem(tokenKey)
		}
	}
	const bindAuth = () => {
		const modal = $('#auth-modal'),
			email = $('#auth-email'),
			pass = $('#auth-pass')
		$('#btn-close-auth')?.addEventListener('click', () =>
			modal.classList.remove('show')
		)
		$('#btn-login')?.addEventListener('click', async () => {
			try {
				const r = await api('/api/auth/login', {
					method: 'POST',
					body: JSON.stringify({ email: email.value, password: pass.value }),
				})
				setToken(r.access_token)
				toast('Вход выполнен')
				modal.classList.remove('show')
				updateUserLabel()
			} catch {
				toast('Ошибка входа')
			}
		})
		$('#btn-register')?.addEventListener('click', async () => {
			try {
				await api('/api/auth/register', {
					method: 'POST',
					body: JSON.stringify({ email: email.value, password: pass.value }),
				})
				const r = await api('/api/auth/login', {
					method: 'POST',
					body: JSON.stringify({ email: email.value, password: pass.value }),
				})
				setToken(r.access_token)
				toast('Аккаунт создан')
				modal.classList.remove('show')
				updateUserLabel()
			} catch {
				toast('Ошибка регистрации')
			}
		})
	}
	const bindUpload = () => {
		const dz = $('#dropzone')
		if (!dz) return
		const input = $('#file-input'),
			choose = $('#btn-choose'),
			chips = $('#uploaded-chips')
		const uploadFile = async file => {
			const fd = new FormData()
			fd.append('file', file)
			const res = await fetch(API + '/api/files/upload', {
				method: 'POST',
				headers: { ...authHeader() },
				body: fd,
			})
			if (!res.ok) throw new Error()
			const j = await res.json()
			const el = document.createElement('span')
			el.className = 'file-chip'
			el.textContent = `${j.file_id} • ${file.name}`
			chips.appendChild(el)
		}
		const onFiles = async fls => {
			for (const f of fls) {
				try {
					await uploadFile(f)
				} catch {
					toast('Ошибка загрузки ' + f.name)
				}
			}
			toast('Загрузка завершена')
		}
		dz.addEventListener('dragover', e => {
			e.preventDefault()
			dz.classList.add('drag')
		})
		dz.addEventListener('dragleave', () => dz.classList.remove('drag'))
		dz.addEventListener('drop', e => {
			e.preventDefault()
			dz.classList.remove('drag')
			onFiles(e.dataTransfer.files)
		})
		choose.addEventListener('click', () => input.click())
		input.addEventListener('change', () => onFiles(input.files))
	}
	const buildParamsForm = async (type, grid) => {
		try {
			const { options: schema = {} } = await api('/api/options/' + type)
			grid.innerHTML = ''
			for (const [key, def] of Object.entries(schema)) {
				const wrap = document.createElement('div')
				const id = 'param-' + key
				const label = document.createElement('label')
				label.textContent = key
				wrap.appendChild(label)
				let input
				if (Array.isArray(def)) {
					input = document.createElement('select')
					def.forEach(v => {
						const o = document.createElement('option')
						o.value = String(v)
						o.textContent = String(v)
						input.appendChild(o)
					})
				} else if (
					typeof def === 'string' &&
					(def.includes('bool') || def === 'boolean')
				) {
					input = document.createElement('select')
					;['false', 'true'].forEach(v => {
						const o = document.createElement('option')
						o.value = v
						o.textContent = v
						input.appendChild(o)
					})
				} else {
					input = document.createElement('input')
					input.placeholder = String(def)
				}
				input.id = id
				wrap.appendChild(input)
				grid.appendChild(wrap)
			}
		} catch {
			toast('Не удалось загрузить параметры')
		}
	}
	const bindFilePicker = (btn, chips, hidden) => {
		if (!btn) return
		btn.addEventListener('click', async () => {
			try {
				const r = await api('/api/files')
				const items = r.items || []
				if (!items.length) return toast('Нет файлов')
				const list = items
					.slice(0, 80)
					.map(x => `${x.id} (${x.mime})`)
					.join('\n')
				const val = prompt('Выберите ID через запятую из списка:\n\n' + list)
				if (!val) return
				const ids = val
					.split(',')
					.map(s => s.trim())
					.filter(Boolean)
				hidden.value = ids.join(',')
				chips.innerHTML = ''
				ids.forEach(id => {
					const tag = document.createElement('span')
					tag.className = 'tag'
					tag.innerHTML = `<span>${id}</span><button>×</button>`
					tag.querySelector('button').onclick = () => {
						hidden.value = hidden.value
							.split(',')
							.filter(x => x && x !== id)
							.join(',')
						tag.remove()
					}
					chips.appendChild(tag)
				})
			} catch {
				toast('Ошибка получения файлов')
			}
		})
	}
	const bindRunTask = (type, btnRun, hidden) => {
		if (!btnRun) return
		btnRun.addEventListener('click', async () => {
			const params = {}
			$$('#params-grid input, #params-grid select').forEach(el => {
				const k = el.id.replace('param-', '')
				let v = el.value
				if (v === 'true') v = true
				else if (v === 'false') v = false
				params[k] = v
			})
			const fileIds = hidden.value
				? hidden.value
						.split(',')
						.map(s => s.trim())
						.filter(Boolean)
				: []
			try {
				const r = await api('/api/tasks', {
					method: 'POST',
					body: JSON.stringify({ type, params, fileIds }),
				})
				toast('Задача создана: ' + r.task_id)
				const tb = $('#recent-tasks tbody')
				if (tb) {
					const tr = document.createElement('tr')
					tr.innerHTML = `<td>${r.task_id}</td><td>${type}</td><td>queued</td><td>0%</td><td>—</td>`
					tb.prepend(tr)
				}
			} catch {
				toast('Ошибка создания задачи')
			}
		})
	}
	const loadRecentTasks = async () => {
		const table = $('#recent-tasks tbody')
		if (!table) return
		try {
			const r = await api('/api/tasks')
			table.innerHTML = ''
			;(r.items || []).forEach(it => {
				const tr = document.createElement('tr')
				tr.innerHTML = `<td>${it.id}</td><td>${it.type}</td><td>${
					it.status
				}</td><td>${
					it.progress || 0
				}%</td><td><a class="btn ghost" href="/tasks.html">Открыть</a></td>`
				table.appendChild(tr)
			})
		} catch {}
	}
	const bindFilesPage = () => {
		const tbody = $('#files-table tbody')
		if (!tbody) return
		const load = async () => {
			const r = await api('/api/files')
			tbody.innerHTML = ''
			;(r.items || []).forEach(f => {
				const tr = document.createElement('tr')
				tr.innerHTML = `<td><input type="checkbox" value="${f.id}"></td><td>${
					f.id
				}</td><td>${f.mime}</td><td>${(f.size / 1024).toFixed(1)} KB</td><td>${
					f.created_at
				}</td><td><a class="btn ghost" href="${API}/api/files/${
					f.id
				}" target="_blank">Скачать</a></td>`
				tbody.appendChild(tr)
			})
		}
		$('#refresh-files')?.addEventListener('click', load)
		$('#delete-selected-files')?.addEventListener('click', async () => {
			const ids = $$('#files-table tbody input[type="checkbox"]:checked').map(
				x => x.value
			)
			if (!ids.length) return toast('Ничего не выбрано')
			if (!confirm('Удалить выбранные файлы?')) return
			await api('/api/files/delete', {
				method: 'POST',
				body: JSON.stringify({ ids }),
			})
			toast('Удалено')
			load()
		})
		load()
	}
	const bindTasksPage = () => {
		const tbody = $('#tasks-table tbody')
		if (!tbody) return
		const row = t =>
			`<tr><td><input type="checkbox" value="${t.id}"></td><td>${
				t.id
			}</td><td>${t.type}</td><td>${
				t.status
			}</td><td><div class="progress"><span style="width:${
				t.progress || 0
			}%"></span></div></td><td>${
				t.created_at || ''
			}</td><td><a class="btn ghost" href="#">Вывод</a></td></tr>`
		const load = async () => {
			const r = await api('/api/tasks')
			tbody.innerHTML = (r.items || []).map(row).join('')
		}
		$('#refresh-tasks')?.addEventListener('click', load)
		$('#delete-selected-tasks')?.addEventListener('click', async () => {
			const ids = $$('#tasks-table tbody input[type="checkbox"]:checked').map(
				x => x.value
			)
			if (!ids.length) return toast('Ничего не выбрано')
			if (!confirm('Удалить выбранные задачи?')) return
			await api('/api/tasks/delete', {
				method: 'POST',
				body: JSON.stringify({ ids }),
			})
			toast('Удалено')
			load()
		})
		load()
		setInterval(load, 5000)
	}
	const bindSettings = () => {
		$('#btn-logout')?.addEventListener('click', () => {
			localStorage.removeItem(tokenKey)
			toast('Выход выполнен')
			updateUserLabel()
		})
		$('#btn-save-profile')?.addEventListener('click', async () => {
			const body = { name: $('#profile-name').value }
			const pass = $('#profile-pass').value
			if (pass) body.password = pass
			try {
				await api('/api/me', { method: 'PATCH', body: JSON.stringify(body) })
				toast('Профиль обновлён')
			} catch {
				toast('Ошибка сохранения')
			}
		})
		$$('button[data-clean]').forEach(b =>
			b.addEventListener('click', async () => {
				const action = b.getAttribute('data-clean')
				if (!confirm('Выполнить очистку: ' + action + '?')) return
				try {
					await api('/api/cleanup', {
						method: 'POST',
						body: JSON.stringify({ action }),
					})
					toast('Готово')
				} catch {
					toast('Ошибка очистки')
				}
			})
		)
	}
	document.addEventListener('DOMContentLoaded', async () => {
		bindAuth()
		updateUserLabel()
		bindUpload()
		const wrap = document.querySelector('[data-task-type]')
		if (wrap) {
			const type = wrap.getAttribute('data-task-type')
			const grid = $('#params-grid')
			await buildParamsForm(type, grid)
			bindFilePicker(
				$('#btn-add-files'),
				$('#file-chips'),
				$('#selected-file-ids')
			)
			bindRunTask(type, $('#btn-run-task'), $('#selected-file-ids'))
			loadRecentTasks()
		}
		bindFilesPage()
		bindTasksPage()
		bindSettings()
	})
})()
